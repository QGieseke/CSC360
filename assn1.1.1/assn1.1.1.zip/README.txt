Quinn Gieseke V00884671

I recieved no help from fellow classmates, only from Stackoverflow, Tutorialpoint, and a little bit of GeeksForGeeks.
I additionally copied no code from the above sites, only looked for refrence, return values, and refreshing memory.

Known bugs:

Cannot compile with -Werror, since I got an error saying wait() has not been defined, despite including its .h, and functionality being present. However, this is the only error I compile with so hopefully it is OK.

